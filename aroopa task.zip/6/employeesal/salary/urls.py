from django.contrib import admin
from django.urls import path
from salary import views
from .views import *

urlpatterns = [
    path('employee/form/', employee_form, name='employee_form'),
    path('', employee_list, name='employee_list'),
    path('<int:pk>/', employee_detail, name='employee_detail'),
    path('create/', employee_create, name='employee_create'),
    path('<int:pk>/update/', employee_update, name='employee_update'),
    path('<int:pk>/delete/', employee_delete, name='employee_delete'),

]